//Create variables here
var dog,dimg,hdog,himg;
var database;
var foodS,foodStock;
function preload()
{
  //load images here
  dimg=loadImage("dogImg.png");
  himg=loadImage("dogImg1.png");
}

function setup() {
	createCanvas(500, 500);
  dog = createSprite();
  dog.addImage("dimg");
}


function draw() {  

  drawSprites();
  //add styles here

}



